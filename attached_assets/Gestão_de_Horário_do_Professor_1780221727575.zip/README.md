
  # Gestão de Horário do Professor

  This is a code bundle for Gestão de Horário do Professor. The original project is available at https://www.figma.com/design/b5g1f8zxm9D0xY9D61TiLG/Gest%C3%A3o-de-Hor%C3%A1rio-do-Professor.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  