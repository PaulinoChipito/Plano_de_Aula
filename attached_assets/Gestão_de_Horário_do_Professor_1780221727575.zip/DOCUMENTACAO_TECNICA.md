# Documentação Técnica Completa - Sistema de Gestão de Horários de Professor

## Arquitetura e Stack Tecnológica

### Stack Principal
- **Framework**: React 18+ com TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS v4.0
- **Animações**: Motion (Framer Motion v12+)
- **Notificações**: Sonner
- **Ícones**: Lucide React
- **Persistência**: LocalStorage API (client-side)

### Estrutura de Diretórios
```
/src/app/
├── App.tsx                 # Componente raiz e orquestração principal
├── components/             # Componentes React reutilizáveis
│   ├── nova-aula-form.tsx  # Formulário de criação/edição de aulas
│   ├── tabela-horarios.tsx # Grid semanal dinâmico
│   ├── bloco-aula.tsx      # Card visual de aula individual
│   └── ui/                 # Design System (Button, Input, Select, etc)
├── hooks/                  # Custom React Hooks
│   └── useAulas.ts         # Gerenciamento de estado global de aulas
├── types/                  # TypeScript Type Definitions
│   └── aula.ts             # Interfaces e tipos principais
└── utils/                  # Funções puras e helpers
    └── horarios.ts         # Algoritmos de validação e cálculo temporal
```

---

## 1. Camada de Tipos e Definições (`/types/aula.ts`)

### Interface `Aula`
```typescript
interface Aula {
  id: string;              // UUID v4 gerado por crypto.randomUUID()
  disciplina: string;      // Nome da disciplina (livre ou predefinida)
  turma: string;           // Identificador da turma (formato livre)
  dia: DiaSemana;          // Dia da semana (enum restrito)
  horaInicio: string;      // Formato "HH:mm" (24h)
  horaFim: string;         // Formato "HH:mm" (24h)
  notificacao: boolean;    // Flag para sistema de notificações futuro
  criadoEm: number;        // Unix timestamp (Date.now())
}
```

### Type `DiaSemana`
Union type discriminado restringindo os dias da semana:
```typescript
type DiaSemana = "Segunda" | "Terça" | "Quarta" | "Quinta" | "Sexta" | "Sábado" | "Domingo"
```

### Constante `DIAS_SEMANA`
Array tipado contendo os dias em ordem sequencial para iteração na grade semanal.

---

## 2. Camada de Utilitários (`/utils/horarios.ts`)

### 2.1 Conversores Temporais

#### `horarioParaMinutos(horario: string): number`
**Algoritmo**: Converte string "HH:mm" para minutos desde meia-noite (00:00)
- **Complexidade**: O(1)
- **Exemplo**: "14:30" → 870 minutos
- **Uso**: Facilita operações aritméticas de comparação e cálculo de intervalos

```typescript
const [horas, minutos] = horario.split(":").map(Number);
return horas * 60 + minutos;
```

#### `minutosParaHorario(minutos: number): string`
**Algoritmo**: Operação inversa, converte minutos para formato "HH:mm" padronizado
- **Complexidade**: O(1)
- **Usa**: `String.padStart(2, "0")` para garantir zero-padding

---

### 2.2 Validadores e Detectores de Conflito

#### `validarHorarios(horaInicio: string, horaFim: string): boolean`
**Validação básica**: Garante que `horaFim > horaInicio`
- Converte ambos para minutos e compara numericamente

#### `verificarConflito(novoInicio, novoFim, aulaExistente): boolean`
**Algoritmo de detecção de sobreposição temporal** (Interval Overlap Detection):
```typescript
// Condição: novo intervalo [A,B] conflita com existente [C,D] se:
// A < D AND B > C
return novoInicioMin < existenteFimMin && novoFimMin > existenteInicioMin;
```
- **Casos cobertos**:
  - Sobreposição parcial (início ou fim)
  - Contenção total (uma aula dentro de outra)
  - Igualdade de fronteiras

#### `verificarConflitosNoDia(dia, horaInicio, horaFim, aulas, aulaEditandoId?): Aula[]`
**Validação contextual**: Retorna array de aulas conflitantes no mesmo dia
- **Filtragem**: Exclui a aula sendo editada (`aulaEditandoId`) para permitir atualização sem falso positivo
- **Performance**: O(n) onde n = número de aulas no dia específico

---

### 2.3 Geração Dinâmica de Grade

#### `extrairHorariosOrdenados(aulas: Aula[]): string[]`
**Algoritmo de construção dinâmica de eixo temporal**:
1. **Extração**: Coleta todos os `horaInicio` e `horaFim` de todas as aulas
2. **Deduplicação**: Usa `Set<string>` para eliminar horários repetidos
3. **Ordenação**: Ordena cronologicamente usando `horarioParaMinutos` para comparação numérica

**Exemplo**:
```typescript
Aulas: [
  {horaInicio: "09:00", horaFim: "10:30"},
  {horaInicio: "08:00", horaFim: "09:00"}
]
Resultado: ["08:00", "09:00", "10:30"] // Ordenado cronologicamente
```

**Complexidade**: O(n log n) devido ao `sort()`

---

### 2.4 Cálculos de Posicionamento Visual

#### `calcularPosicaoTop(horaInicio, primeiroHorario, ultimoHorario): number`
**Propósito**: Calcula a posição `top` (em %) do bloco de aula no container
**Fórmula**:
```typescript
totalMinutos = ultimoHorario - primeiroHorario
posicaoMinutos = horaInicio - primeiroHorario
percentual = (posicaoMinutos / totalMinutos) × 100
```

**Exemplo Prático**:
- Grade: 08:00 - 18:00 (600 minutos totais)
- Aula inicia às 10:00 (120 minutos após 08:00)
- Top = (120 / 600) × 100 = **20%**

#### `calcularAltura(horaInicio, horaFim, primeiroHorario, ultimoHorario): number`
**Propósito**: Calcula a altura (em %) do bloco proporcional à duração da aula
**Fórmula**:
```typescript
duracaoMinutos = horaFim - horaInicio
height = (duracaoMinutos / totalMinutos) × 100
```

**Exemplo**:
- Aula de 1h30 (90 minutos) em grade de 10h (600 minutos)
- Altura = (90 / 600) × 100 = **15%**

#### `gerarCorPorDisciplina(disciplina: string): string`
**Algoritmo de hashing determinístico** para cores consistentes:
1. Calcula hash numérico da string disciplina usando **djb2-like algorithm**
2. Mapeia hash para paleta de 10 cores Tailwind via módulo (`%`)
3. **Garantia**: Mesma disciplina sempre retorna mesma cor

```typescript
let hash = 0;
for (let i = 0; i < disciplina.length; i++) {
  hash = disciplina.charCodeAt(i) + ((hash << 5) - hash);
}
const index = Math.abs(hash) % cores.length;
```

---

## 3. Camada de Estado (`/hooks/useAulas.ts`)

### Custom Hook `useAulas()`

**Responsabilidades**:
- Gerenciamento centralizado do array de aulas
- Sincronização bidirecional com localStorage
- Operações CRUD completas

#### Estrutura de Estado
```typescript
const [aulas, setAulas] = useState<Aula[]>([])
```

#### Persistência com LocalStorage

**Carregamento Inicial** (`useEffect` com deps vazias):
```typescript
useEffect(() => {
  const stored = localStorage.getItem("aulas_professor");
  if (stored) setAulas(JSON.parse(stored));
}, []); // Executa apenas no mount
```

**Sincronização Automática** (`useEffect` observando `aulas`):
```typescript
useEffect(() => {
  localStorage.setItem("aulas_professor", JSON.stringify(aulas));
}, [aulas]); // Dispara a cada mutação
```

**Tratamento de Erro**: Try-catch para casos de:
- Quota excedida do localStorage (geralmente 5-10MB)
- JSON malformado
- Modo privado/incognito com storage desabilitado

#### Operações CRUD

**Create**: `adicionarAula(aula: Aula)`
```typescript
setAulas((prev) => [...prev, aula]); // Imutabilidade via spread
```

**Update**: `atualizarAula(id: string, aulaAtualizada: Partial<Aula>)`
```typescript
setAulas((prev) => 
  prev.map((aula) => 
    aula.id === id ? { ...aula, ...aulaAtualizada } : aula
  )
);
```
- Usa `Partial<Aula>` para permitir atualizações parciais
- Merge via spread operator

**Delete**: `excluirAula(id: string)`
```typescript
setAulas((prev) => prev.filter((aula) => aula.id !== id));
```

**Read**: Métodos auxiliares
- `obterAulaPorId(id: string): Aula | undefined`
- `obterAulasPorDia(dia: string): Aula[]`

---

## 4. Camada de Componentes

### 4.1 `NovaAulaForm.tsx` - Formulário de Criação/Edição

#### Estado Local
```typescript
const [disciplina, setDisciplina] = useState("")
const [disciplinaCustom, setDisciplinaCustom] = useState("") // Para disciplinas não listadas
const [turma, setTurma] = useState("")
const [dia, setDia] = useState("")
const [horaInicio, setHoraInicio] = useState("")
const [horaFim, setHoraFim] = useState("")
const [notificacao, setNotificacao] = useState(false)
const [erros, setErros] = useState<string[]>([])
const [sucesso, setSucesso] = useState(false)
```

#### Modo Edição vs Criação
**Detecção**: Prop `aulaEditando?: Aula | null`
- Se presente: preenche formulário com dados existentes
- Se ausente: formulário em branco

**Efeito de Sincronização**:
```typescript
useEffect(() => {
  if (aulaEditando) {
    // Popula todos os campos
    // Detecta se disciplina é customizada ou da lista predefinida
    setDisciplina(
      DISCIPLINAS_SUGERIDAS.includes(aulaEditando.disciplina)
        ? aulaEditando.disciplina
        : "custom"
    );
  }
}, [aulaEditando]);
```

#### Sistema de Validação Multi-Camada

**1. Validação de Campos Obrigatórios**:
```typescript
if (!disciplinaFinal.trim()) novosErros.push("Disciplina é obrigatória");
if (!turma.trim()) novosErros.push("Turma é obrigatória");
if (!dia) novosErros.push("Dia da semana é obrigatório");
// ... etc
```

**2. Validação Temporal**:
```typescript
if (!validarHorarios(horaInicio, horaFim)) {
  novosErros.push("A hora de fim deve ser maior que a hora de início");
}
```

**3. Detecção de Conflitos**:
```typescript
const conflitos = verificarConflitosNoDia(dia, horaInicio, horaFim, aulas, aulaEditando?.id);
if (conflitos.length > 0) {
  novosErros.push(
    `Conflito com: ${conflitos.map(c => `${c.disciplina} (${c.horaInicio} - ${c.horaFim})`).join(", ")}`
  );
}
```

#### Fluxo de Submissão
```typescript
handleSubmit(e) {
  e.preventDefault();
  if (!validarFormulario()) return; // Early return em erro
  
  const aula: Aula = {
    id: aulaEditando?.id || crypto.randomUUID(), // Reutiliza ID em edição
    disciplina: disciplina === "custom" ? disciplinaCustom : disciplina,
    turma, dia, horaInicio, horaFim, notificacao,
    criadoEm: aulaEditando?.criadoEm || Date.now() // Preserva timestamp original
  };
  
  onSubmit(aula);
  
  // Limpa formulário apenas se for criação (não em edição)
  if (!aulaEditando) { /* reset fields */ }
}
```

#### UX/UI Avançada
- **Auto-dismiss**: Toast de sucesso desaparece após 3s (`useEffect` com timer)
- **Campos Condicionais**: Input customizado aparece se `disciplina === "custom"`
- **Scroll Automático**: Ao editar, scroll suave para o formulário

---

### 4.2 `TabelaHorarios.tsx` - Grid Semanal Dinâmico

#### Arquitetura de Camadas Sobrepostas

**Camada 1: Grid Base (HTML Table-like)**
```typescript
<div className="grid grid-cols-[120px_repeat(7,1fr)]">
  {/* Cabeçalho fixo */}
  <div>Horário</div>
  {DIAS_SEMANA.map(dia => <div>{dia}</div>)}
  
  {/* Linhas de horário */}
  {horariosOrdenados.map(horario => (
    <>
      <div>{horario}</div> {/* Coluna de horários */}
      {DIAS_SEMANA.map(dia => (
        <div style={{height: "80px"}}> {/* Célula vazia */}
          <Plus /> {/* Botão "+" para nova aula */}
        </div>
      ))}
    </>
  ))}
</div>
```

**Camada 2: Blocos de Aula Posicionados Absolutamente**
```typescript
<div className="relative" style={{ marginTop: `-${totalHeight}px` }}>
  {/* Overlay sobre a grade base */}
  <div className="grid grid-cols-[120px_repeat(7,1fr)]">
    <div /> {/* Espaço para coluna de horários */}
    {DIAS_SEMANA.map(dia => (
      <div className="relative">
        {obterAulasDoDia(dia).map(aula => (
          <BlocoAula 
            style={{
              position: "absolute",
              top: `${calcularPosicaoTop(...)}%`,
              height: `${calcularAltura(...)}%`
            }}
          />
        ))}
      </div>
    ))}
  </div>
</div>
```

**Técnica de Margin Negativo**: Permite sobrepor a camada de blocos sobre o grid base mantendo alinhamento perfeito

#### Geração Dinâmica de Linhas
```typescript
const horariosOrdenados = extrairHorariosOrdenados(aulas);
// Ex: ["08:00", "09:00", "10:30", "12:00"]

// Tabela ajusta-se automaticamente:
// - 4 aulas → 4+ linhas
// - 20 aulas → 20+ linhas
```

#### Sticky Positioning
- **Cabeçalho**: `sticky top-0` - Dias da semana sempre visíveis
- **Coluna de Horários**: `sticky left-0` - Horários fixos no scroll horizontal

#### Responsividade
```typescript
<ScrollArea className="w-full">
  <div className="min-w-[900px]"> {/* Força scroll horizontal em telas pequenas */}
    {/* Grid */}
  </div>
  <ScrollBar orientation="horizontal" />
</ScrollArea>
```

---

### 4.3 `BlocoAula.tsx` - Card Visual de Aula

#### Cálculo de Posicionamento
```typescript
const cor = gerarCorPorDisciplina(aula.disciplina);
const top = calcularPosicaoTop(aula.horaInicio, primeiroHorario, ultimoHorario);
const altura = calcularAltura(aula.horaInicio, aula.horaFim, primeiroHorario, ultimoHorario);
```

#### Animação de Entrada (Framer Motion)
```typescript
<motion.div
  initial={{ opacity: 0, scale: 0.95 }}
  animate={{ opacity: 1, scale: 1 }}
  exit={{ opacity: 0, scale: 0.95 }}
  transition={{ duration: 0.2 }}
>
```

#### Estados Interativos

**Hover**:
- Eleva shadow (`hover:shadow-xl`)
- Aumenta escala (`hover:scale-[1.02]`)
- Revela botões de ação (`opacity-0 group-hover:opacity-100`)

**Botões de Ação**:
```typescript
// Editar
<Button onClick={(e) => {
  e.stopPropagation(); // Previne duplo trigger do onClick do card
  onEditar(aula);
}}>
  <Edit2 />
</Button>

// Excluir
<Button onClick={(e) => {
  e.stopPropagation();
  if (window.confirm(`Excluir ${aula.disciplina}?`)) {
    onExcluir(aula.id);
  }
}}>
  <Trash2 />
</Button>
```

#### Hierarquia Visual
```
┌─────────────────────┐
│ Turma (bold, large) │ ← Informação primária
│ Disciplina (normal) │ ← Contexto
│ 08:00 - 09:30       │ ← Temporal
│                     │
│ [🔔] (se notif)     │ ← Indicadores
└─────────────────────┘
  ↑ Botões no hover
```

---

## 5. Componente Raiz (`App.tsx`)

### Orquestração de Estado
```typescript
const { aulas, adicionarAula, atualizarAula, excluirAula } = useAulas();
const [aulaEditando, setAulaEditando] = useState<Aula | null>(null);
```

### Fluxo de Dados (Data Flow)

**Criação/Edição**:
```
NovaAulaForm 
  → handleSubmitAula 
    → if (editing) atualizarAula() else adicionarAula()
      → useAulas (state update)
        → localStorage (persist)
          → TabelaHorarios (re-render)
```

**Exclusão**:
```
BlocoAula 
  → onExcluir 
    → handleExcluirAula 
      → excluirAula(id)
        → useAulas (filter)
          → localStorage
            → TabelaHorarios (re-render sem a aula)
```

### Sistema de Notificações (Sonner)
```typescript
toast.success("Aula criada com sucesso!");
toast.error("Erro ao salvar");
toast.info("Preencha os dados");
```
- Posicionamento: `top-right`
- Auto-dismiss: 3-5 segundos
- Rich colors: Variantes visuais por tipo

### Estatísticas Computadas
```typescript
const totalAulas = aulas.length;
const disciplinasUnicas = new Set(aulas.map(a => a.disciplina)).size;
const turmasUnicas = new Set(aulas.map(a => a.turma)).size;
```
- **Complexidade**: O(n) para cada métrica
- **Recomputa**: A cada mudança em `aulas` (React re-render)

### Layout Responsivo
```typescript
<div className="grid grid-cols-1 lg:grid-cols-[350px_1fr]">
  <aside>Formulário (350px fixo em desktop)</aside>
  <main>Tabela (espaço restante)</main>
</div>
```

**Breakpoint**: `lg:` (1024px)
- Mobile: Stack vertical
- Desktop: Sidebar + conteúdo

---

## 6. Fluxos Críticos e Edge Cases

### 6.1 Fluxo de Edição Completo
1. Usuário clica em `BlocoAula`
2. `onEditar(aula)` chamado
3. `setAulaEditando(aula)` atualiza estado em `App.tsx`
4. `NovaAulaForm` recebe `aulaEditando` via props
5. `useEffect` detecta mudança e preenche campos
6. Usuário modifica campos
7. Ao submeter, `handleSubmitAula` detecta modo edição
8. Chama `atualizarAula(id, novosDados)`
9. Toast de sucesso exibido
10. Formulário limpo, `aulaEditando` resetado

### 6.2 Detecção de Conflitos em Edição
**Problema**: Ao editar aula, não deve detectar conflito consigo mesma
**Solução**: 
```typescript
verificarConflitosNoDia(dia, horaInicio, horaFim, aulas, aulaEditando?.id)
                                                          ↑
                                        Exclui aula sendo editada da verificação
```

### 6.3 Sincronização Form ↔ Estado
**Desafio**: Formulário controlado (controlled inputs) com modo edição
**Implementação**:
- Todos os inputs usam `value={state}` e `onChange={setState}`
- `useEffect` sincroniza quando `aulaEditando` muda
- Botão "Cancelar" limpa campos e reseta `aulaEditando`

### 6.4 Edge Cases Tratados
- **Horário fim ≤ início**: Validação bloqueia
- **Sobreposição parcial**: Algoritmo de intervalo detecta
- **Disciplina customizada vazia**: Validação exige preenchimento
- **LocalStorage cheio**: Try-catch previne crash
- **JSON corrompido**: Parse protegido com try-catch
- **Exclusão durante edição**: Verifica se `aulaEditando.id === id` e reseta

---

## 7. Performance e Otimizações

### Complexidade Algorítmica
- **Adição de aula**: O(1) + O(n) para validação de conflitos no dia
- **Remoção de aula**: O(n) para filter
- **Renderização de grid**: O(m × 7) onde m = número de horários únicos
- **Detecção de conflitos**: O(k) onde k = aulas no dia específico (não todas)

### Otimizações Aplicadas
1. **Filtragem de conflitos por dia**: Não verifica todas as aulas, apenas do mesmo dia
2. **Set para deduplicação**: `extrairHorariosOrdenados` usa Set (O(1) lookup)
3. **Controlled inputs**: Evita re-renders desnecessários
4. **LocalStorage assíncrono**: `useEffect` não bloqueia UI
5. **Motion.div**: GPU-accelerated animations

### Pontos de Atenção
- **LocalStorage sync**: Pode causar lag com >1000 aulas (considerar debounce)
- **Scroll performance**: Grid com muitas linhas pode ser otimizado com virtualização
- **Memory leaks**: Timer do toast limpo no cleanup do useEffect

---

## 8. Padrões de Código e Convenções

### TypeScript
- **Strict mode**: Todas as tipagens explícitas
- **No any**: Uso de `unknown` ou tipos específicos
- **Utility types**: `Partial<Aula>` para updates parciais
- **Type guards**: Verificação de `aulaEditando?.id`

### React
- **Hooks**: Apenas functional components
- **Imutabilidade**: Spread operators para updates
- **Key props**: Sempre únicos (IDs, não índices)
- **Controlled components**: Inputs controlados via state

### CSS/Tailwind
- **Utility-first**: Classes inline, sem CSS customizado
- **Responsive**: Mobile-first com breakpoints
- **Dark mode ready**: Uso de `bg-gray-50` não hardcoded
- **Acessibilidade**: Labels com htmlFor, ARIA implícito

---

## 9. Possíveis Extensões e Roadmap

### Features Identificadas (Não Implementadas)
1. **Sistema de Notificações**: Flag `notificacao` preparada, backend necessário
2. **Filtros**: Por disciplina, turma, dia
3. **Exportação**: PDF, iCal para calendários
4. **Multi-usuário**: Atualmente single-user (localStorage)
5. **Drag & Drop**: Reposicionar aulas arrastando
6. **Recorrência**: Aulas que se repetem semanalmente
7. **Cores customizáveis**: Escolher cor por disciplina manualmente
8. **Dark mode**: Estrutura CSS preparada

### Migração para Backend
**Preparação atual**: Estrutura facilita migração:
```typescript
// useAulas.ts - trocar localStorage por API calls
const adicionarAula = async (aula: Aula) => {
  await fetch("/api/aulas", { method: "POST", body: JSON.stringify(aula) });
  setAulas(prev => [...prev, aula]);
};
```

---

## 10. Glossário Técnico

- **Grid dinâmico**: Tabela que se adapta ao número de horários cadastrados
- **Sticky positioning**: CSS `position: sticky` para cabeçalhos fixos
- **Controlled component**: Input cujo valor é controlado por React state
- **Immutable update**: Atualização de estado sem mutação direta
- **Hash determinístico**: Algoritmo que sempre retorna mesmo resultado para mesma entrada
- **Interval overlap**: Detecção matemática de sobreposição entre dois intervalos
- **LocalStorage**: API do navegador para persistência client-side (5-10MB)
- **UUID**: Identificador único universal (RFC 4122)
- **Spread operator**: Sintaxe `...obj` para cópia shallow de objetos/arrays
- **Type guard**: Verificação de tipo em TypeScript (ex: `?.` optional chaining)

---

## Conclusão

Este sistema implementa uma solução completa e profissional para gestão de horários acadêmicos, com:

✅ **Arquitetura Escalável**: Separação clara de responsabilidades  
✅ **Validação Robusta**: Multi-camada com detecção de conflitos  
✅ **UX Polida**: Animações, feedback visual, responsividade  
✅ **Type Safety**: TypeScript estrito em toda a codebase  
✅ **Performance**: Algoritmos otimizados, complexidade controlada  
✅ **Persistência**: LocalStorage com sync bidirecional  
✅ **Manutenibilidade**: Código limpo, comentado e modular  

A estrutura atual suporta fácil extensão para features avançadas (backend, notificações, filtros) mantendo a simplicidade e clareza do código existente.
