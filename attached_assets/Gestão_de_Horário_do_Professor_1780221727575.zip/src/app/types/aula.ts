export interface Aula {
  id: string;
  disciplina: string;
  turma: string;
  dia: string;
  horaInicio: string; // "HH:mm"
  horaFim: string; // "HH:mm"
  notificacao: boolean;
  criadoEm: number;
}

export type DiaSemana = 
  | "Segunda"
  | "Terça"
  | "Quarta"
  | "Quinta"
  | "Sexta"
  | "Sábado"
  | "Domingo";

export const DIAS_SEMANA: DiaSemana[] = [
  "Segunda",
  "Terça",
  "Quarta",
  "Quinta",
  "Sexta",
  "Sábado",
  "Domingo",
];
