import { useState, useEffect } from "react";
import { Aula, DIAS_SEMANA } from "../types/aula";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "./ui/select";
import { Switch } from "./ui/switch";
import { Alert, AlertDescription } from "./ui/alert";
import {
  validarHorarios,
  verificarConflitosNoDia,
} from "../utils/horarios";
import { AlertCircle, Check, X } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";

interface NovaAulaFormProps {
  aulas: Aula[];
  onSubmit: (aula: Aula) => void;
  aulaEditando?: Aula | null;
  onCancelar?: () => void;
}

// Lista de disciplinas sugeridas
const DISCIPLINAS_SUGERIDAS = [
  "Matemática",
  "Português",
  "História",
  "Geografia",
  "Ciências",
  "Física",
  "Química",
  "Biologia",
  "Inglês",
  "Educação Física",
  "Arte",
  "Filosofia",
  "Sociologia",
];

export function NovaAulaForm({
  aulas,
  onSubmit,
  aulaEditando,
  onCancelar,
}: NovaAulaFormProps) {
  const [disciplina, setDisciplina] = useState("");
  const [disciplinaCustom, setDisciplinaCustom] = useState("");
  const [turma, setTurma] = useState("");
  const [dia, setDia] = useState("");
  const [horaInicio, setHoraInicio] = useState("");
  const [horaFim, setHoraFim] = useState("");
  const [notificacao, setNotificacao] = useState(false);
  const [erros, setErros] = useState<string[]>([]);
  const [sucesso, setSucesso] = useState(false);

  // Preencher formulário quando estiver editando
  useEffect(() => {
    if (aulaEditando) {
      setDisciplina(
        DISCIPLINAS_SUGERIDAS.includes(aulaEditando.disciplina)
          ? aulaEditando.disciplina
          : "custom"
      );
      setDisciplinaCustom(
        DISCIPLINAS_SUGERIDAS.includes(aulaEditando.disciplina)
          ? ""
          : aulaEditando.disciplina
      );
      setTurma(aulaEditando.turma);
      setDia(aulaEditando.dia);
      setHoraInicio(aulaEditando.horaInicio);
      setHoraFim(aulaEditando.horaFim);
      setNotificacao(aulaEditando.notificacao);
      setSucesso(false);
    }
  }, [aulaEditando]);

  // Limpar mensagem de sucesso após 3 segundos
  useEffect(() => {
    if (sucesso) {
      const timer = setTimeout(() => setSucesso(false), 3000);
      return () => clearTimeout(timer);
    }
  }, [sucesso]);

  const validarFormulario = (): boolean => {
    const novosErros: string[] = [];

    const disciplinaFinal =
      disciplina === "custom" ? disciplinaCustom : disciplina;

    if (!disciplinaFinal.trim()) {
      novosErros.push("Disciplina é obrigatória");
    }

    if (!turma.trim()) {
      novosErros.push("Turma é obrigatória");
    }

    if (!dia) {
      novosErros.push("Dia da semana é obrigatório");
    }

    if (!horaInicio) {
      novosErros.push("Hora de início é obrigatória");
    }

    if (!horaFim) {
      novosErros.push("Hora de fim é obrigatória");
    }

    if (horaInicio && horaFim && !validarHorarios(horaInicio, horaFim)) {
      novosErros.push("A hora de fim deve ser maior que a hora de início");
    }

    if (dia && horaInicio && horaFim) {
      const conflitos = verificarConflitosNoDia(
        dia,
        horaInicio,
        horaFim,
        aulas,
        aulaEditando?.id
      );

      if (conflitos.length > 0) {
        novosErros.push(
          `Conflito de horário detectado com: ${conflitos
            .map((c) => `${c.disciplina} (${c.horaInicio} - ${c.horaFim})`)
            .join(", ")}`
        );
      }
    }

    setErros(novosErros);
    return novosErros.length === 0;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!validarFormulario()) {
      return;
    }

    const disciplinaFinal =
      disciplina === "custom" ? disciplinaCustom : disciplina;

    const aula: Aula = {
      id: aulaEditando?.id || crypto.randomUUID(),
      disciplina: disciplinaFinal,
      turma,
      dia,
      horaInicio,
      horaFim,
      notificacao,
      criadoEm: aulaEditando?.criadoEm || Date.now(),
    };

    onSubmit(aula);

    // Limpar formulário apenas se não estiver editando
    if (!aulaEditando) {
      setDisciplina("");
      setDisciplinaCustom("");
      setTurma("");
      setDia("");
      setHoraInicio("");
      setHoraFim("");
      setNotificacao(false);
    }

    setErros([]);
    setSucesso(true);
  };

  const handleCancelar = () => {
    setDisciplina("");
    setDisciplinaCustom("");
    setTurma("");
    setDia("");
    setHoraInicio("");
    setHoraFim("");
    setNotificacao(false);
    setErros([]);
    setSucesso(false);
    onCancelar?.();
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          {aulaEditando ? "Editar Aula" : "Nova Aula"}
          {aulaEditando && (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={handleCancelar}
            >
              <X className="w-4 h-4" />
            </Button>
          )}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Disciplina */}
          <div className="space-y-2">
            <Label htmlFor="disciplina">Disciplina</Label>
            <Select value={disciplina} onValueChange={setDisciplina}>
              <SelectTrigger id="disciplina">
                <SelectValue placeholder="Selecione uma disciplina" />
              </SelectTrigger>
              <SelectContent>
                {DISCIPLINAS_SUGERIDAS.map((disc) => (
                  <SelectItem key={disc} value={disc}>
                    {disc}
                  </SelectItem>
                ))}
                <SelectItem value="custom">Outra...</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Disciplina Custom */}
          {disciplina === "custom" && (
            <div className="space-y-2">
              <Label htmlFor="disciplina-custom">Nome da Disciplina</Label>
              <Input
                id="disciplina-custom"
                value={disciplinaCustom}
                onChange={(e) => setDisciplinaCustom(e.target.value)}
                placeholder="Digite o nome da disciplina"
              />
            </div>
          )}

          {/* Turma */}
          <div className="space-y-2">
            <Label htmlFor="turma">Turma</Label>
            <Input
              id="turma"
              value={turma}
              onChange={(e) => setTurma(e.target.value)}
              placeholder="Ex: 3º A, 9º Ano, Turma 101"
            />
          </div>

          {/* Dia da Semana */}
          <div className="space-y-2">
            <Label htmlFor="dia">Dia da Semana</Label>
            <Select value={dia} onValueChange={setDia}>
              <SelectTrigger id="dia">
                <SelectValue placeholder="Selecione o dia" />
              </SelectTrigger>
              <SelectContent>
                {DIAS_SEMANA.map((d) => (
                  <SelectItem key={d} value={d}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Horários */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="hora-inicio">Hora de Início</Label>
              <Input
                id="hora-inicio"
                type="time"
                value={horaInicio}
                onChange={(e) => setHoraInicio(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="hora-fim">Hora de Fim</Label>
              <Input
                id="hora-fim"
                type="time"
                value={horaFim}
                onChange={(e) => setHoraFim(e.target.value)}
              />
            </div>
          </div>

          {/* Notificação */}
          <div className="flex items-center space-x-2">
            <Switch
              id="notificacao"
              checked={notificacao}
              onCheckedChange={setNotificacao}
            />
            <Label htmlFor="notificacao" className="cursor-pointer">
              Ativar notificação
            </Label>
          </div>

          {/* Erros */}
          {erros.length > 0 && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                <ul className="list-disc list-inside space-y-1">
                  {erros.map((erro, index) => (
                    <li key={index}>{erro}</li>
                  ))}
                </ul>
              </AlertDescription>
            </Alert>
          )}

          {/* Sucesso */}
          {sucesso && (
            <Alert className="border-green-500 text-green-700 bg-green-50">
              <Check className="h-4 w-4" />
              <AlertDescription>
                Aula {aulaEditando ? "atualizada" : "criada"} com sucesso!
              </AlertDescription>
            </Alert>
          )}

          {/* Botões */}
          <div className="flex gap-2">
            <Button type="submit" className="flex-1">
              {aulaEditando ? "Atualizar Aula" : "Criar Aula"}
            </Button>
            {aulaEditando && (
              <Button
                type="button"
                variant="outline"
                onClick={handleCancelar}
              >
                Cancelar
              </Button>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
