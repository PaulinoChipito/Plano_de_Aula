import { Aula } from "../types/aula";
import {
  gerarCorPorDisciplina,
  calcularPosicaoTop,
  calcularAltura,
  formatarIntervaloHorario,
} from "../utils/horarios";
import { motion } from "motion/react";
import { Edit2, Trash2, Bell } from "lucide-react";
import { Button } from "./ui/button";

interface BlocoAulaProps {
  aula: Aula;
  primeiroHorario: string;
  ultimoHorario: string;
  onEditar: (aula: Aula) => void;
  onExcluir: (id: string) => void;
}

export function BlocoAula({
  aula,
  primeiroHorario,
  ultimoHorario,
  onEditar,
  onExcluir,
}: BlocoAulaProps) {
  const cor = gerarCorPorDisciplina(aula.disciplina);
  const top = calcularPosicaoTop(
    aula.horaInicio,
    primeiroHorario,
    ultimoHorario
  );
  const altura = calcularAltura(
    aula.horaInicio,
    aula.horaFim,
    primeiroHorario,
    ultimoHorario
  );

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.2 }}
      className={`absolute left-0 right-0 mx-1 ${cor} text-white rounded-lg shadow-lg overflow-hidden group cursor-pointer transition-all hover:shadow-xl hover:scale-[1.02]`}
      style={{
        top: `${top}%`,
        height: `${altura}%`,
        minHeight: "60px",
      }}
      onClick={() => onEditar(aula)}
    >
      <div className="p-3 h-full flex flex-col justify-between relative">
        {/* Conteúdo principal */}
        <div className="flex-1 min-h-0">
          <div className="font-semibold text-sm truncate">{aula.turma}</div>
          <div className="text-xs opacity-90 truncate">{aula.disciplina}</div>
          <div className="text-xs opacity-75 mt-1">
            {formatarIntervaloHorario(aula.horaInicio, aula.horaFim)}
          </div>
        </div>

        {/* Indicador de notificação */}
        {aula.notificacao && (
          <div className="mt-1">
            <Bell className="w-3 h-3 opacity-75" />
          </div>
        )}

        {/* Botões de ação - aparecem no hover */}
        <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0 bg-white/20 hover:bg-white/30"
            onClick={(e) => {
              e.stopPropagation();
              onEditar(aula);
            }}
          >
            <Edit2 className="w-3 h-3" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            className="h-7 w-7 p-0 bg-white/20 hover:bg-red-500"
            onClick={(e) => {
              e.stopPropagation();
              if (
                window.confirm(
                  `Deseja realmente excluir a aula de ${aula.disciplina}?`
                )
              ) {
                onExcluir(aula.id);
              }
            }}
          >
            <Trash2 className="w-3 h-3" />
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
