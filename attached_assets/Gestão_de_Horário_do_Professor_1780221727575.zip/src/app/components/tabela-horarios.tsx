import { Aula, DIAS_SEMANA } from "../types/aula";
import { extrairHorariosOrdenados } from "../utils/horarios";
import { BlocoAula } from "./bloco-aula";
import { Plus } from "lucide-react";
import { ScrollArea, ScrollBar } from "./ui/scroll-area";

interface TabelaHorariosProps {
  aulas: Aula[];
  onEditarAula: (aula: Aula) => void;
  onExcluirAula: (id: string) => void;
  onNovaAula?: (dia?: string, horario?: string) => void;
}

export function TabelaHorarios({
  aulas,
  onEditarAula,
  onExcluirAula,
  onNovaAula,
}: TabelaHorariosProps) {
  // Extrair horários únicos das aulas e ordenar
  const horariosOrdenados = extrairHorariosOrdenados(aulas);

  const obterAulasDoDia = (dia: string): Aula[] => {
    return aulas.filter((aula) => aula.dia === dia);
  };

  // Se não há aulas, mostrar mensagem
  if (horariosOrdenados.length === 0) {
    return (
      <div className="w-full rounded-lg border bg-white p-12 text-center">
        <p className="text-gray-500">
          Nenhuma aula cadastrada. As atividades aparecerão aqui organizadas cronologicamente.
        </p>
      </div>
    );
  }

  const primeiroHorario = horariosOrdenados[0];
  const ultimoHorario = horariosOrdenados[horariosOrdenados.length - 1];
  const alturaLinha = 80; // altura de cada linha em pixels

  return (
    <div className="w-full">
      <ScrollArea className="w-full rounded-lg border">
        <div className="min-w-[900px]">
          {/* Grid principal */}
          <div className="grid grid-cols-[120px_repeat(7,1fr)] bg-white">
            {/* Header - Cabeçalho fixo */}
            <div className="sticky top-0 z-20 bg-gray-100 border-b-2 border-gray-300">
              {/* Canto superior esquerdo - Horário */}
              <div className="h-16 flex items-center justify-center border-r border-gray-300">
                <span className="text-sm font-semibold text-gray-600">
                  Horário
                </span>
              </div>
            </div>

            {/* Dias da semana */}
            {DIAS_SEMANA.map((dia) => (
              <div
                key={dia}
                className="sticky top-0 z-20 bg-gray-100 border-b-2 border-gray-300 border-r border-gray-200"
              >
                <div className="h-16 flex items-center justify-center">
                  <span className="font-semibold text-gray-700">{dia}</span>
                </div>
              </div>
            ))}

            {/* Corpo da tabela */}
            {horariosOrdenados.map((horario, index) => (
              <div
                key={horario}
                className="contents"
                style={{ gridRow: index + 2 }}
              >
                {/* Coluna de horários - mostra os horários das aulas */}
                <div className="sticky left-0 z-10 bg-gray-50 border-r border-b border-gray-300 flex items-center justify-center px-2"
                     style={{ height: `${alturaLinha}px` }}>
                  <span className="text-sm text-gray-700 font-medium">
                    {horario}
                  </span>
                </div>

                {/* Células dos dias */}
                {DIAS_SEMANA.map((dia) => {
                  return (
                    <div
                      key={`${dia}-${horario}`}
                      className="relative border-r border-b border-gray-200 bg-white hover:bg-gray-50 transition-colors group"
                      style={{ height: `${alturaLinha}px` }}
                    >
                      {/* Botão "+" para adicionar aula rápida */}
                      <button
                        className="absolute inset-0 w-full h-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        onClick={() => onNovaAula?.(dia, horario)}
                      >
                        <Plus className="w-5 h-5 text-gray-400 hover:text-gray-600" />
                      </button>
                    </div>
                  );
                })}
              </div>
            ))}
          </div>

          {/* Camada de blocos de aula - posicionamento absoluto */}
          <div className="relative" style={{ marginTop: `-${horariosOrdenados.length * alturaLinha}px` }}>
            <div className="grid grid-cols-[120px_repeat(7,1fr)]">
              {/* Espaço para coluna de horários */}
              <div />

              {/* Container para cada dia */}
              {DIAS_SEMANA.map((dia) => {
                const aulasDoDia = obterAulasDoDia(dia);

                return (
                  <div
                    key={`blocos-${dia}`}
                    className="relative"
                    style={{ height: `${horariosOrdenados.length * alturaLinha}px` }}
                  >
                    {aulasDoDia.map((aula) => (
                      <BlocoAula
                        key={aula.id}
                        aula={aula}
                        primeiroHorario={primeiroHorario}
                        ultimoHorario={ultimoHorario}
                        onEditar={onEditarAula}
                        onExcluir={onExcluirAula}
                      />
                    ))}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  );
}