import { useState, useEffect } from "react";
import { HorarioTrabalho } from "../hooks/useHorarioTrabalho";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Clock, X } from "lucide-react";
import { validarHorarios } from "../utils/horarios";
import { Alert, AlertDescription } from "./ui/alert";
import { AlertCircle } from "lucide-react";

interface HorarioTrabalhoFormProps {
  horarioTrabalho: HorarioTrabalho | null;
  onSubmit: (horario: HorarioTrabalho) => void;
  onLimpar?: () => void;
}

export function HorarioTrabalhoForm({
  horarioTrabalho,
  onSubmit,
  onLimpar,
}: HorarioTrabalhoFormProps) {
  const [horaEntrada, setHoraEntrada] = useState("");
  const [horaSaida, setHoraSaida] = useState("");
  const [erro, setErro] = useState("");

  useEffect(() => {
    if (horarioTrabalho) {
      setHoraEntrada(horarioTrabalho.horaEntrada);
      setHoraSaida(horarioTrabalho.horaSaida);
    }
  }, [horarioTrabalho]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErro("");

    if (!horaEntrada || !horaSaida) {
      setErro("Preencha ambos os horários");
      return;
    }

    if (!validarHorarios(horaEntrada, horaSaida)) {
      setErro("A hora de saída deve ser maior que a hora de entrada");
      return;
    }

    onSubmit({ horaEntrada, horaSaida });
  };

  const handleLimpar = () => {
    setHoraEntrada("");
    setHoraSaida("");
    setErro("");
    onLimpar?.();
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Clock className="w-5 h-5" />
          Horário de Trabalho
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="entrada">Hora de Entrada</Label>
              <Input
                id="entrada"
                type="time"
                value={horaEntrada}
                onChange={(e) => setHoraEntrada(e.target.value)}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="saida">Hora de Saída</Label>
              <Input
                id="saida"
                type="time"
                value={horaSaida}
                onChange={(e) => setHoraSaida(e.target.value)}
              />
            </div>
          </div>

          {erro && (
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{erro}</AlertDescription>
            </Alert>
          )}

          <div className="flex gap-2">
            <Button type="submit" className="flex-1">
              {horarioTrabalho ? "Atualizar" : "Definir"} Horário
            </Button>
            {horarioTrabalho && (
              <Button
                type="button"
                variant="outline"
                size="icon"
                onClick={handleLimpar}
              >
                <X className="w-4 h-4" />
              </Button>
            )}
          </div>
        </form>
      </CardContent>
    </Card>
  );
}
