import { Aula } from "../types/aula";

/**
 * Converte string de horário "HH:mm" para minutos desde meia-noite
 */
export function horarioParaMinutos(horario: string): number {
  const [horas, minutos] = horario.split(":").map(Number);
  return horas * 60 + minutos;
}

/**
 * Converte minutos desde meia-noite para string "HH:mm"
 */
export function minutosParaHorario(minutos: number): string {
  const horas = Math.floor(minutos / 60);
  const mins = minutos % 60;
  return `${String(horas).padStart(2, "0")}:${String(mins).padStart(2, "0")}`;
}

/**
 * Valida se horaFim é maior que horaInicio
 */
export function validarHorarios(horaInicio: string, horaFim: string): boolean {
  const inicio = horarioParaMinutos(horaInicio);
  const fim = horarioParaMinutos(horaFim);
  return fim > inicio;
}

/**
 * Verifica se há conflito entre dois horários
 */
export function verificarConflito(
  novoInicio: string,
  novoFim: string,
  aulaExistente: Aula
): boolean {
  const novoInicioMin = horarioParaMinutos(novoInicio);
  const novoFimMin = horarioParaMinutos(novoFim);
  const existenteInicioMin = horarioParaMinutos(aulaExistente.horaInicio);
  const existenteFimMin = horarioParaMinutos(aulaExistente.horaFim);

  return novoInicioMin < existenteFimMin && novoFimMin > existenteInicioMin;
}

/**
 * Verifica conflitos com todas as aulas do mesmo dia
 */
export function verificarConflitosNoDia(
  dia: string,
  horaInicio: string,
  horaFim: string,
  aulas: Aula[],
  aulaEditandoId?: string
): Aula[] {
  const aulasDoDia = aulas.filter(
    (aula) => aula.dia === dia && aula.id !== aulaEditandoId
  );

  return aulasDoDia.filter((aula) =>
    verificarConflito(horaInicio, horaFim, aula)
  );
}

/**
 * Gera intervalos de tempo para a grade (ex: 08:00, 08:30, 09:00...)
 */
export function gerarIntervalosHorarios(
  inicio: string = "07:00",
  fim: string = "22:00",
  intervaloMinutos: number = 60
): string[] {
  const inicioMin = horarioParaMinutos(inicio);
  const fimMin = horarioParaMinutos(fim);
  const intervalos: string[] = [];

  for (let min = inicioMin; min <= fimMin; min += intervaloMinutos) {
    intervalos.push(minutosParaHorario(min));
  }

  return intervalos;
}

/**
 * Calcula a posição top do bloco de aula (em %)
 */
export function calcularPosicaoTop(
  horaInicio: string,
  primeiroHorario: string,
  ultimoHorario: string
): number {
  const inicioMin = horarioParaMinutos(horaInicio);
  const primeiroMin = horarioParaMinutos(primeiroHorario);
  const ultimoMin = horarioParaMinutos(ultimoHorario);

  const totalMinutos = ultimoMin - primeiroMin;
  const posicaoMinutos = inicioMin - primeiroMin;

  return (posicaoMinutos / totalMinutos) * 100;
}

/**
 * Calcula a altura do bloco de aula (em %)
 */
export function calcularAltura(
  horaInicio: string,
  horaFim: string,
  primeiroHorario: string,
  ultimoHorario: string
): number {
  const inicioMin = horarioParaMinutos(horaInicio);
  const fimMin = horarioParaMinutos(horaFim);
  const primeiroMin = horarioParaMinutos(primeiroHorario);
  const ultimoMin = horarioParaMinutos(ultimoHorario);

  const totalMinutos = ultimoMin - primeiroMin;
  const duracaoMinutos = fimMin - inicioMin;

  return (duracaoMinutos / totalMinutos) * 100;
}

/**
 * Gera cor baseada em hash de string (disciplina)
 */
export function gerarCorPorDisciplina(disciplina: string): string {
  let hash = 0;
  for (let i = 0; i < disciplina.length; i++) {
    hash = disciplina.charCodeAt(i) + ((hash << 5) - hash);
  }

  const cores = [
    "bg-blue-500",
    "bg-purple-500",
    "bg-pink-500",
    "bg-green-500",
    "bg-yellow-500",
    "bg-orange-500",
    "bg-red-500",
    "bg-indigo-500",
    "bg-teal-500",
    "bg-cyan-500",
  ];

  const index = Math.abs(hash) % cores.length;
  return cores[index];
}

/**
 * Formata horário para exibição (ex: 08:00 - 09:30)
 */
export function formatarIntervaloHorario(
  horaInicio: string,
  horaFim: string
): string {
  return `${horaInicio} - ${horaFim}`;
}

/**
 * Extrai todos os horários únicos das aulas e ordena cronologicamente
 */
export function extrairHorariosOrdenados(aulas: Aula[]): string[] {
  const horariosSet = new Set<string>();
  
  aulas.forEach((aula) => {
    horariosSet.add(aula.horaInicio);
    horariosSet.add(aula.horaFim);
  });

  const horarios = Array.from(horariosSet);
  
  // Ordenar cronologicamente
  horarios.sort((a, b) => {
    return horarioParaMinutos(a) - horarioParaMinutos(b);
  });

  return horarios;
}