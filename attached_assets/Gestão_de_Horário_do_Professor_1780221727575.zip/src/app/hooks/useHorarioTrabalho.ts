import { useState, useEffect } from "react";

export interface HorarioTrabalho {
  horaEntrada: string;
  horaSaida: string;
}

const STORAGE_KEY = "horario_trabalho_professor";

export function useHorarioTrabalho() {
  const [horarioTrabalho, setHorarioTrabalho] = useState<HorarioTrabalho | null>(null);

  // Carregar horário do localStorage ao inicializar
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setHorarioTrabalho(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Erro ao carregar horário de trabalho:", error);
    }
  }, []);

  // Salvar horário no localStorage sempre que mudar
  useEffect(() => {
    try {
      if (horarioTrabalho) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(horarioTrabalho));
      } else {
        localStorage.removeItem(STORAGE_KEY);
      }
    } catch (error) {
      console.error("Erro ao salvar horário de trabalho:", error);
    }
  }, [horarioTrabalho]);

  const definirHorarioTrabalho = (horario: HorarioTrabalho) => {
    setHorarioTrabalho(horario);
  };

  const limparHorarioTrabalho = () => {
    setHorarioTrabalho(null);
  };

  return {
    horarioTrabalho,
    definirHorarioTrabalho,
    limparHorarioTrabalho,
  };
}
