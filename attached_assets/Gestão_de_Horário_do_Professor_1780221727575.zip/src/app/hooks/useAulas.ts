import { useState, useEffect } from "react";
import { Aula } from "../types/aula";

const STORAGE_KEY = "aulas_professor";

export function useAulas() {
  const [aulas, setAulas] = useState<Aula[]>([]);

  // Carregar aulas do localStorage ao inicializar
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setAulas(JSON.parse(stored));
      }
    } catch (error) {
      console.error("Erro ao carregar aulas:", error);
    }
  }, []);

  // Salvar aulas no localStorage sempre que mudar
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(aulas));
    } catch (error) {
      console.error("Erro ao salvar aulas:", error);
    }
  }, [aulas]);

  const adicionarAula = (aula: Aula) => {
    setAulas((prev) => [...prev, aula]);
  };

  const atualizarAula = (id: string, aulaAtualizada: Partial<Aula>) => {
    setAulas((prev) =>
      prev.map((aula) =>
        aula.id === id ? { ...aula, ...aulaAtualizada } : aula
      )
    );
  };

  const excluirAula = (id: string) => {
    setAulas((prev) => prev.filter((aula) => aula.id !== id));
  };

  const obterAulaPorId = (id: string): Aula | undefined => {
    return aulas.find((aula) => aula.id === id);
  };

  const obterAulasPorDia = (dia: string): Aula[] => {
    return aulas.filter((aula) => aula.dia === dia);
  };

  return {
    aulas,
    adicionarAula,
    atualizarAula,
    excluirAula,
    obterAulaPorId,
    obterAulasPorDia,
  };
}
