import { useState } from "react";
import { NovaAulaForm } from "./components/nova-aula-form";
import { TabelaHorarios } from "./components/tabela-horarios";
import { useAulas } from "./hooks/useAulas";
import { Aula } from "./types/aula";
import { toast, Toaster } from "sonner";
import { Calendar, BookOpen, Clock } from "lucide-react";
import { Card, CardContent } from "./components/ui/card";

export default function App() {
  const {
    aulas,
    adicionarAula,
    atualizarAula,
    excluirAula,
  } = useAulas();

  const [aulaEditando, setAulaEditando] = useState<Aula | null>(null);

  const handleSubmitAula = (aula: Aula) => {
    if (aulaEditando) {
      atualizarAula(aula.id, aula);
      toast.success("Aula atualizada com sucesso!");
      setAulaEditando(null);
    } else {
      adicionarAula(aula);
      toast.success("Aula criada com sucesso!");
    }
  };

  const handleEditarAula = (aula: Aula) => {
    setAulaEditando(aula);
    // Scroll suave para o formulário
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleExcluirAula = (id: string) => {
    excluirAula(id);
    toast.success("Aula excluída com sucesso!");
    if (aulaEditando?.id === id) {
      setAulaEditando(null);
    }
  };

  const handleCancelarEdicao = () => {
    setAulaEditando(null);
  };

  const handleNovaAulaRapida = (dia?: string, horario?: string) => {
    setAulaEditando(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
    toast.info("Preencha os dados da nova aula");
  };

  // Estatísticas
  const totalAulas = aulas.length;
  const disciplinasUnicas = new Set(aulas.map((a) => a.disciplina)).size;
  const turmasUnicas = new Set(aulas.map((a) => a.turma)).size;

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      <Toaster position="top-right" richColors />

      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="container mx-auto px-4 py-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                Gestão de Horários
              </h1>
              <p className="text-gray-600 mt-1">
                Organize e gerencie seus horários de aula
              </p>
            </div>

            {/* Estatísticas */}
            <div className="flex gap-4">
              <Card className="bg-blue-50 border-blue-200">
                <CardContent className="p-4 flex items-center gap-3">
                  <Clock className="w-8 h-8 text-blue-600" />
                  <div>
                    <div className="text-2xl font-bold text-blue-900">
                      {totalAulas}
                    </div>
                    <div className="text-xs text-blue-700">Aulas</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-purple-50 border-purple-200">
                <CardContent className="p-4 flex items-center gap-3">
                  <BookOpen className="w-8 h-8 text-purple-600" />
                  <div>
                    <div className="text-2xl font-bold text-purple-900">
                      {disciplinasUnicas}
                    </div>
                    <div className="text-xs text-purple-700">Disciplinas</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-green-50 border-green-200">
                <CardContent className="p-4 flex items-center gap-3">
                  <Calendar className="w-8 h-8 text-green-600" />
                  <div>
                    <div className="text-2xl font-bold text-green-900">
                      {turmasUnicas}
                    </div>
                    <div className="text-xs text-green-700">Turmas</div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-[350px_1fr] gap-6">
          {/* Sidebar - Formulário */}
          <div className="lg:sticky lg:top-8 h-fit">
            <div className="space-y-4">
              <NovaAulaForm
                aulas={aulas}
                onSubmit={handleSubmitAula}
                aulaEditando={aulaEditando}
                onCancelar={handleCancelarEdicao}
              />
            </div>
          </div>

          {/* Tabela de Horários */}
          <div>
            <div className="mb-4">
              <h2 className="text-2xl font-semibold text-gray-900">
                Grade Semanal
              </h2>
              <p className="text-gray-600 text-sm mt-1">
                Clique nas aulas para editar ou nas células vazias para adicionar
              </p>
            </div>

            <TabelaHorarios
              aulas={aulas}
              onEditarAula={handleEditarAula}
              onExcluirAula={handleExcluirAula}
              onNovaAula={handleNovaAulaRapida}
            />

            {/* Mensagem quando não há aulas */}
            {totalAulas === 0 && (
              <div className="mt-8 text-center p-12 bg-white rounded-lg border-2 border-dashed border-gray-300">
                <Calendar className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-gray-700 mb-2">
                  Nenhuma aula cadastrada
                </h3>
                <p className="text-gray-500">
                  Comece criando sua primeira aula usando o formulário ao lado
                </p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="mt-16 py-6 border-t bg-white">
        <div className="container mx-auto px-4 text-center text-gray-600 text-sm">
          <p>
            Sistema de Gestão de Horários • {new Date().getFullYear()}
          </p>
        </div>
      </footer>
    </div>
  );
}